#ifndef _P7_3_DODAJ_H
#define _P7_3_DODAJ_H

#include "p7_3_liczydlo.h"

struct A {
    int a;
    int b;
};

extern int ilosc_wywolan;
float dodaj(float a, float b);

#endif