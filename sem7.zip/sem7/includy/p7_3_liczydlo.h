#ifndef _p7_3_liczydlo_h
#define _p7_3_liczydlo_h

#include "p7_3_dodaj.h"

#define MOJ_TYP double


MOJ_TYP sumuj(MOJ_TYP a, MOJ_TYP b, MOJ_TYP c);

#endif