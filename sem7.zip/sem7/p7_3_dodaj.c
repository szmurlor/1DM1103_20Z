#include "includy/p7_3_dodaj.h"

int ilosc_wywolan = 0;

float dodaj(float a, float b) {
    ilosc_wywolan++;
    return a+b;
}