#include "includy/p7_3_liczydlo.h"

MOJ_TYP sumuj(MOJ_TYP a, MOJ_TYP b, MOJ_TYP c) {
    return dodaj( dodaj(a,b), c);
}
